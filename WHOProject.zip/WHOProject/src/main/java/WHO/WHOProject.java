/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package WHO;

/**
 *
 * @author nojus
 */
public class WHOProject {

    public static void main(String[] args) {
        Landing landing = new Landing();
        landing.setVisible(true);
    }
}
